import { Component, OnInit } from '@angular/core';
import { Booking } from 'src/model/Booking';
import { Employee } from 'src/model/Employee';
import { BookingService } from '../booking.service';


@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  booking:Booking[]=[]
  stack:Employee[]=[]
  constructor(private service:BookingService) {
    this.loadBooking();
   }
   loadBooking() {
    this.service.getAllBookings().subscribe(success => this.booking = success);
   }
   //updating BookingById 
   putBookingById(id:number){
    this.service.putBookingbyId(id).subscribe(s=>console.log(s))
  }
 
  //deleting BookingById 
  deleteBookingbyId(id:number){
    this.service.deleteBookingbyId(id).subscribe(s=>console.log(s))
  }
   
  ngOnInit() {
  }

}