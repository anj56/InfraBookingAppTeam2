import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/model/User';
import { UserService } from '../user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user:User=new User();
  constructor(private service:UserService,private router:Router) { 
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  //login By Username 
  PerformLogin()
  {
    let result=this.service.checkUser(this.user)
    if(result){
      this.router.navigate(['booking'])
    }
    else{
      alert('invalid user name and password')
      this.user.userName='';
      this.user.password=''
    }
    //update By Id
    PerformUpdate()
  {
    let result=this.service.checkUser(this.user)
    if(result){
      this.router.navigate(['booking'])
    }
    else{
      alert('invalid user name and password')
      this.user.userName='';
      this.user.password=''
    }
  }
  ngOnInit() 
  }

}




function PerformUpdate() {
  throw new Error('Function not implemented.');
}

function ngOnInit() {
  throw new Error('Function not implemented.');
}

