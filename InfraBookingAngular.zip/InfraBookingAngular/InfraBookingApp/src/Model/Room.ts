export class Room{
    constructor(public code:string,public capacity:number){

    }
}